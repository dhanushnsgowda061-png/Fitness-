# My Daily Fitness Tracker - build the Android APK on GitHub

You do NOT need Android Studio. GitHub builds the APK for you, free.

## One-time setup
1. Make a free account at https://github.com
2. Click "+" (top right) > "New repository". Name it fitness-tracker. Choose Public or Private. Click "Create repository".
3. Click "uploading an existing file". Unzip this zip on your computer first.
4. Open the unzipped folder, select EVERYTHING inside it (including the hidden .github folder) and drag it into GitHub.
   Tip: if .github does not upload, use the "Add file > Create new file" button, type
   .github/workflows/build-apk.yml as the name, and paste the file text in.
5. Click "Commit changes".

## Build the APK
1. Open the "Actions" tab. If asked, click "I understand, enable workflows".
2. Click "Build APK" on the left, then "Run workflow", then the green "Run workflow" button.
3. Wait 5-10 minutes. A green tick means it worked. A red cross means it failed: open it and read the error.
4. Click the finished run, scroll to "Artifacts", download "fitness-tracker-apk". Unzip it: app-debug.apk is inside.

## Install on your phone
1. Copy app-debug.apk to your phone (WhatsApp to yourself, Google Drive, USB).
2. Tap the file. Android asks to allow "Install unknown apps" for that app: allow it.
3. Tap Install. Open "My Daily Fitness Tracker".

## Keep your data safe
- Data is stored only inside the app on your phone.
- Uninstalling the app DELETES the data. Export a backup first (Backup tab).
- To update: build a new APK and install it OVER the old one. Do not uninstall. Do not change
  appId in capacitor.config.json or replace debug.keystore, or Android will refuse the update.
- Backup button opens the Android share sheet: save to Drive or send to yourself.

## Updating the tracker
Replace www/index.html on GitHub (pencil icon or upload), commit, run "Build APK" again.

## Notes
- This is a debug-signed APK for your own phone. For Google Play you need a private release key
  (do not use the included public debug.keystore).
- Or skip the APK: host the www folder with GitHub Pages and use Chrome > "Install app".
