# Puts the tracker icon into the generated Android project. Skips anything missing.
import os
from PIL import Image, ImageDraw
RES='android/app/src/main/res'
def art(size,bg,scale=1.0):
    im=Image.new('RGBA',(size,size),bg);d=ImageDraw.Draw(im);u=size/192*scale;o=size*(1-scale)/2
    f=lambda x,y,w,h:[o+x*u,o+y*u,o+(x+w)*u,o+(y+h)*u]
    d.rectangle(f(38,88,116,16),fill='white')
    for x in(30,146):d.rounded_rectangle(f(x,60,16,72),radius=5*u,fill='#e8a317')
    for x in(14,162):d.rounded_rectangle(f(x,76,16,40),radius=4*u,fill='white')
    return im
legacy={'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}
fore={'mdpi':108,'hdpi':162,'xhdpi':216,'xxhdpi':324,'xxxhdpi':432}
for k in legacy:
    d=f'{RES}/mipmap-{k}'
    if not os.path.isdir(d):continue
    for n in('ic_launcher.png','ic_launcher_round.png'):art(legacy[k],'#0d7a5f').save(f'{d}/{n}')
    art(fore[k],(0,0,0,0),0.62).save(f'{d}/ic_launcher_foreground.png')
v=f'{RES}/values'
if os.path.isdir(v):open(f'{v}/ic_launcher_background.xml','w').write('<?xml version="1.0" encoding="utf-8"?><resources><color name="ic_launcher_background">#0d7a5f</color></resources>')
print('icons done')
